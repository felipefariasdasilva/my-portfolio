package com.felipe.myportfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyportfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
